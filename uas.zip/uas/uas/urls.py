from django.contrib import admin
from django.urls import path, include

from . import views

urlpatterns = [
    path('jet/', include('jet.urls', 'jet')),
    path('jet/dashboard/', include('jet.dashboard.urls', 'jet-dashboard')),
    path('admin/', admin.site.urls),
    path('', views.index),
    path('penduduk/', include('penduduk.urls')),
    path('kecamatan/', include('kecamatan.urls')),
]
