from django.shortcuts import render

from . models import penduduk

def index(request):
    postingan = penduduk.objects.all()

    context = {
        'TampungPostingan':postingan,
    }

    return render(request, 'penduduk/index.html', context)