from django.db import models

class Kecamatan(models.Model):
    Kecamatan = models.CharField(max_length=100)

    def __str__(self):
        return self.Kecamatan

class penduduk(models.Model):
    Nik = models.CharField(max_length=255)
    Nama = models.TextField(max_length=20)
    Kecamatan = models.ForeignKey(Kecamatan, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return self.Nik