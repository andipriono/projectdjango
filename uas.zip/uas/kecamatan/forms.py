from django import forms

class Kecamatan(forms.Form):
    Nik = forms.CharField(max_length=20)
    Nama = forms.CharField(max_length=20)
    Kecamatan = forms.CharField(
        widget = forms.Textarea)
    