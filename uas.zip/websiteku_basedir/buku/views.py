from django.shortcuts import render

from . models import Book

def index(request):

    postingan = Book.objects.all()

    context = {
        'TampungPostingan': postingan,
    }

    return render(request, 'buku/index.html', context)
 